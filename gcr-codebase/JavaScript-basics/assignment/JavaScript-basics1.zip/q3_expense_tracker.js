// Q3. Monthly Expense Tracker
// Calculates total, average and final amount (with 10% tax).

// Expenses for 5 categories
const expenses = {
  food: 6500,
  travel: 2200,
  rent: 12000,
  bills: 3400,
  leisure: 1800,
};

const amounts = Object.values(expenses);

// Total using assignment operator (+=)
let total = 0;
for (const amount of amounts) {
  total += amount;
}

// Average expense per category
const average = total / amounts.length;

// Add 10% tax using arithmetic and assignment operators
const taxRate = 10;
let finalAmount = total;
finalAmount += total * taxRate / 100;

console.log("Total Expense        : ₹" + total.toFixed(2));
console.log("Average per Category : ₹" + average.toFixed(2));
console.log("Final Amount (+10%)  : ₹" + finalAmount.toFixed(2));
