// Q8. Employee Salary Projection
// Projects salary for 5 years with a yearly increment.

const currentSalary = 500000;   // starting annual salary (₹)
const incrementRate = 8;        // annual increment in %

let salary = currentSalary;
const projection = [];

for (let year = 1; year <= 5; year++) {
  salary += salary * incrementRate / 100; // apply increment
  salary = Math.round(salary);            // rounding
  projection.push({ Year: year, Salary: salary });
}

console.log(`Starting salary: ₹${currentSalary} | Increment: ${incrementRate}% per year`);
console.table(projection);
