// Q2. Multi-Type Data Summary
// Declares variables of different types and prints one formatted console.table().

const fullName = "Sumit Kumar";                       // string
const age = 21;                                       // number
const isStudent = true;                               // boolean
const skills = ["JavaScript", "Python", "Networking"]; // array
const profile = { university: "GLA", city: "Mathura" }; // object
const middleName = null;                              // null
let phoneNumber;                                      // undefined (never assigned)

// Helper: typeof returns "object" for arrays and null, so handle them explicitly
function getType(value) {
  if (Array.isArray(value)) return "array";
  if (value === null) return "null";
  return typeof value;
}

// Build the report rows (label + value + type)
const report = [
  { Label: "fullName",    Value: fullName,                  Type: getType(fullName) },
  { Label: "age",         Value: age,                       Type: getType(age) },
  { Label: "isStudent",   Value: isStudent,                 Type: getType(isStudent) },
  { Label: "skills",      Value: JSON.stringify(skills),    Type: getType(skills) },
  { Label: "profile",     Value: JSON.stringify(profile),   Type: getType(profile) },
  { Label: "middleName",  Value: middleName,                Type: getType(middleName) },
  { Label: "phoneNumber", Value: phoneNumber,               Type: getType(phoneNumber) },
];

// Single console.table() statement
console.table(report);
