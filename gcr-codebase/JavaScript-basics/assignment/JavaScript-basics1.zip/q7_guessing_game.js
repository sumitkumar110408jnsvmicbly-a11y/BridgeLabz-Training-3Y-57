// Q7. Smart Guessing Game (Number Range)

// Secret number between 1 and 50
const secretNumber = Math.floor(Math.random() * 50) + 1;

// Test value for the user's guess
const userGuess = 25;

console.log("Your guess:", userGuess);

if (userGuess === secretNumber) {
  console.log("Correct guess!");
} else {
  // Nested condition: check closeness first
  if (userGuess >= secretNumber - 3 && userGuess <= secretNumber + 3) {
    console.log("Very close!");
  } else if (userGuess > secretNumber) {
    console.log("Too high");
  } else {
    console.log("Too low");
  }
}

// Revealed only for testing purposes
console.log("(Secret number was " + secretNumber + ")");
