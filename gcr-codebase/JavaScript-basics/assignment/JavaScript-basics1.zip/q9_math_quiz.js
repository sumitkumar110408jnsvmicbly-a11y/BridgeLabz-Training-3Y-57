// Q9. Random Math Quiz Generator

// Random integer between 1 and 20
function randomNumber() {
  return Math.floor(Math.random() * 20) + 1;
}

const num1 = randomNumber();
const num2 = randomNumber();

const operators = ['+', '-', '*', '/'];
const operator = operators[Math.floor(Math.random() * operators.length)];

let answer;

// Calculate the correct answer with a switch statement
switch (operator) {
  case '+':
    answer = num1 + num2;
    break;
  case '-':
    answer = num1 - num2;
    break;
  case '*':
    answer = num1 * num2;
    break;
  case '/':
    answer = (num1 / num2).toFixed(2); // two decimals for division
    break;
  default:
    answer = "Invalid operator";
}

console.log(`Question: ${num1} ${operator} ${num2} = ?`);
console.log(`Correct Answer: ${answer}`);
