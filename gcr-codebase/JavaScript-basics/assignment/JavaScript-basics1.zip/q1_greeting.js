// Q1. Personalized Login Greeting
// Greets the user based on the current hour of the day.

const userName = "Sumit";                 // name of the logged-in user
const currentHour = new Date().getHours(); // 0 - 23

let greeting;

if (currentHour < 12) {
  // Before noon
  greeting = "Good Morning";
} else if (currentHour >= 12 && currentHour <= 17) {
  // 12:00 to 17:59
  greeting = "Good Afternoon";
} else {
  // 18:00 onwards
  greeting = "Good Evening";
}

// Template literal for the final message
console.log(`${greeting} ${userName}!`);
