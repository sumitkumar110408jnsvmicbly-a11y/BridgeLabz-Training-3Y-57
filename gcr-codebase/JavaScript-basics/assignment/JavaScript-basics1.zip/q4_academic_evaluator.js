// Q4. Academic Performance Evaluator
// Decides whether a student is promoted, promoted with distinction, or detained.

// Marks of 5 subjects (each out of 100)
const marks = [78, 92, 65, 88, 71];
const maxMarksPerSubject = 100;

// Total, average and percentage
let totalMarks = 0;
for (const mark of marks) {
  totalMarks += mark;
}
const average = totalMarks / marks.length;
const percentage = (totalMarks / (marks.length * maxMarksPerSubject)) * 100;

// Validation: any subject below 35 -> automatic detention
const failedAnySubject = marks.some(mark => mark < 35);

let result;
if (failedAnySubject) {
  result = "Detained";
} else if (percentage >= 85) {
  result = "Promoted with Distinction";
} else if (percentage >= 50 && percentage < 85) {
  result = "Promoted";
} else {
  result = "Detained";
}

console.log("Marks      :", marks.join(", "));
console.log("Average    :", average.toFixed(2));
console.log("Percentage :", percentage.toFixed(2) + "%");
if (failedAnySubject) {
  console.log("Note       : Scored below 35 in at least one subject.");
}
console.log("Result     :", result);
