// Q10. Citizen Eligibility Validator
//
// NOTE: The assignment's rules overlap (a citizen aged 18-20 also satisfies
// "citizen and age >= 18"). To make every outcome reachable, "all services"
// requires age 21 or more (the typical driving/passport-ready age here), and
// citizens aged 18-20 get "vote only".

const age = 19;
const isCitizen = true;

if (isCitizen) {
  if (age >= 21) {
    console.log("Eligible for all services.");
  } else if (age >= 18 && age <= 20) {
    console.log("Eligible to vote only.");
  } else {
    console.log("Not eligible yet.");
  }
} else {
  if (age >= 18) {
    console.log("Only age criteria met.");
  } else {
    console.log("Not eligible yet.");
  }
}
