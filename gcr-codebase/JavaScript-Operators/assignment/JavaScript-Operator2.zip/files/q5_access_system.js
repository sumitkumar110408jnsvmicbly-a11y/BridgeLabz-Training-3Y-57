// Q5. Boolean Logic Access System

function checkSecurity(isDoorLocked, isWindowClosed, isAlarmOn, isOwnerInside) {
  // Door and window must be closed, alarm on, owner inside.
  // (A locked door counts as a closed door.)
  const isSecure = isAlarmOn && isDoorLocked && isWindowClosed && isOwnerInside;

  // Using ! and || to describe why it is unsafe
  const hasOpening = !isDoorLocked || !isWindowClosed;

  console.log(
    `Door locked: ${isDoorLocked}, Window closed: ${isWindowClosed}, ` +
    `Alarm on: ${isAlarmOn}, Owner inside: ${isOwnerInside}`
  );
  console.log(isSecure ? "Result: Secure" : "Result: Unsafe");
  if (!isSecure && hasOpening) console.log("Reason: door or window is not secured.");
  if (!isSecure && !isAlarmOn) console.log("Reason: alarm is off.");
  if (!isSecure && !isOwnerInside) console.log("Reason: owner is not inside.");
  console.log("-----");
}

// Test multiple outcomes
checkSecurity(true, true, true, true);   // Secure
checkSecurity(false, true, true, true);  // Unsafe (door)
checkSecurity(true, true, false, true);  // Unsafe (alarm)
checkSecurity(true, true, true, false);  // Unsafe (owner)
checkSecurity(false, false, false, false); // Unsafe (everything)
