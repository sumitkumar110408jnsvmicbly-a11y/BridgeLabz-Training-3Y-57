// Q6. Event-Based Counter Simulation

let count = 0; // shared counter

// Increase the counter
function increment() {
  count++;
  console.log("Incremented -> count =", count);
}

// Decrease the counter
function decrement() {
  count--;
  console.log("Decremented -> count =", count);
}

// Nested function example: the inner function can read and update 'count'
// of the outer function because of function (lexical) scope.
function createStepCounter() {
  let stepCount = 0; // visible only inside createStepCounter and its inner functions

  function addStep() {            // nested function
    stepCount += 5;
    console.log("Nested addStep -> stepCount =", stepCount);
  }

  addStep();
  addStep();
  return stepCount;
}

// Simulate "click" events by calling the functions manually
console.log("Initial count:", count);
increment(); // click +
increment(); // click +
increment(); // click +
decrement(); // click -
decrement(); // click -

const finalSteps = createStepCounter();
console.log("Final stepCount returned from outer function:", finalSteps);
console.log("Final count:", count);
