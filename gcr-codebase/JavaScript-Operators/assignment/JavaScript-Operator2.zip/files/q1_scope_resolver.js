
const bonus = 5000;

function calculateSalary(permanentStatus) {

  const salary = 40000;
  const isPermanent = permanentStatus; 

  let totalSalary = salary;

  if (isPermanent === true) {
    totalSalary += bonus;
  }

  console.log(`isPermanent = ${isPermanent} -> Total salary: ₹${totalSalary}`);
}

calculateSalary(true);

calculateSalary(false);

console.log("Global bonus after both calls:", bonus);

console.log("typeof salary outside function:", typeof salary);          
console.log("typeof isPermanent outside function:", typeof isPermanent); 
