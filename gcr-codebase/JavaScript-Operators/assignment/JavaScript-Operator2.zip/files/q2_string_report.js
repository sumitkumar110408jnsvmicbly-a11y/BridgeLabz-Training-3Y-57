// Q2. String Manipulation Report
// Cleans and formats a product title before display.

const productName = "  wireless headphones PRO  ";

// Step 1: remove extra spaces and convert to lowercase
const cleaned = productName.trim().toLowerCase();

// Step 2: replace the word "pro" with "Pro Edition"
// (done before capitalising; \b makes sure only the whole word "pro" matches)
const replaced = cleaned.replace(/\bpro\b/, "Pro Edition");

// Step 3: capitalise the first letter of each word
const formattedTitle = replaced
  .split(" ")                                          // break into words
  .map(word => word.charAt(0).toUpperCase() + word.slice(1)) // capitalise each word
  .join(" ");                                          // join back to a string

console.log("Original      :", `"${productName}"`);
console.log("Cleaned title :", `"${formattedTitle}"`);
console.log("Length        :", formattedTitle.length);
