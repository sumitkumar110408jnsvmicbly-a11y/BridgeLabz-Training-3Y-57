// Q4. Array Performance Analyzer

// Create an array of 8 random scores between 30 and 100
const scores = Array.from({ length: 8 }, () => Math.floor(Math.random() * 71) + 30);

// Highest and lowest
const highest = Math.max(...scores);
const lowest = Math.min(...scores);

// Average using reduce()
const total = scores.reduce((sum, score) => sum + score, 0);
const average = total / scores.length;

// Students who passed (>= 50) using filter()
const passedScores = scores.filter(score => score >= 50);
const passedCount = passedScores.length;

// map() to attach a Pass/Fail label to each score
const labelled = scores.map(score => `${score} (${score >= 50 ? "Pass" : "Fail"})`);

console.log("===== Performance Summary =====");
console.log("Scores        :", labelled.join(", "));
console.log("Highest score :", highest);
console.log("Lowest score  :", lowest);
console.log("Average score :", average.toFixed(2));
console.log(`Passed        : ${passedCount} out of ${scores.length}`);
console.log("===============================");
