// Q8. Dynamic Discount Evaluator

const cart = [
  { item: "Laptop", category: "electronics", price: 45000 },
  { item: "Shoes", category: "fashion", price: 2500 },
  { item: "Book", category: "education", price: 600 }
];

// Step 1: apply category discount to each item using a loop
const discountedItems = [];
for (const product of cart) {
  let discountPercent = 0;

  if (product.category === "electronics") {
    discountPercent = 10;
  } else if (product.category === "fashion") {
    discountPercent = 5;
  }

  const finalPrice = product.price - (product.price * discountPercent) / 100;
  discountedItems.push({ ...product, discountPercent, finalPrice });

  console.log(`${product.item}: ₹${product.price} - ${discountPercent}% = ₹${finalPrice}`);
}

// Step 2: totals using reduce()
const originalTotal = cart.reduce((sum, product) => sum + product.price, 0);
let finalTotal = discountedItems.reduce((sum, product) => sum + product.finalPrice, 0);

// Step 3: extra 5% if the cart value (before discounts) is above 50000
if (originalTotal > 50000) {
  finalTotal -= (finalTotal * 5) / 100;
  console.log("Extra 5% cart discount applied.");
} else {
  console.log("Cart value not above ₹50000, no extra discount.");
}

console.log("Original total:", "₹" + originalTotal);
console.log("Final total   :", "₹" + finalTotal.toFixed(2));
