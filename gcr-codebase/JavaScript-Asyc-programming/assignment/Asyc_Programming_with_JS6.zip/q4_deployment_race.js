"use strict";

const failureChance = 0.2;

function deployToServer(name, delay) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < failureChance) {
        reject(new Error(`${name} failed to respond`));
      } else {
        resolve(`${name} responded in ${delay / 1000}s`);
      }
    }, delay);
  });
}

const serverA = deployToServer("Server A", 2000);
const serverB = deployToServer("Server B", 3000);

Promise.all([serverA, serverB])
  .then(results => {
    console.log("Deployment completed for all servers");
    results.forEach(result => console.log(`  ${result}`));
  })
  .catch(error => console.log(`Promise.all failed: ${error.message}`));

Promise.race([serverA, serverB])
  .then(result => console.log("Fastest response:", result))
  .catch(error => console.log(`Promise.race failed: ${error.message}`));
