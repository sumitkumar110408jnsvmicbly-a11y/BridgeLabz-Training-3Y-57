"use strict";

function loadProfile() { return new Promise(r => setTimeout(() => r("Profile Loaded"), 2000)); }
function loadPosts() { return new Promise(r => setTimeout(() => r("Posts Loaded"), 1500)); }
function loadMessages() { return new Promise(r => setTimeout(() => r("Messages Loaded"), 1000)); }

function failRandomly(loaders) {
  const failIndex = Math.floor(Math.random() * loaders.length);
  return loaders.map((loader, index) =>
    index === failIndex
      ? () => loader().then(() => Promise.reject(new Error("Failed to load")))
      : loader
  );
}

const moduleNames = ["Profile", "Posts", "Messages"];
const loaders = failRandomly([loadProfile, loadPosts, loadMessages]);

const startTime = Date.now();

Promise.allSettled(loaders.map(loader => loader())).then(results => {
  const totalTime = Date.now() - startTime;

  results.forEach((result, index) => {
    if (result.status === "fulfilled") {
      console.log(`${moduleNames[index]}: succeeded -> ${result.value}`);
    } else {
      console.log(`${moduleNames[index]}: failed -> ${result.reason.message}`);
    }
  });

  console.log(`Total time taken: ${totalTime} ms`);
});
