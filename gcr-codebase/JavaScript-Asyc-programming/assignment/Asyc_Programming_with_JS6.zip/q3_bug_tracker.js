"use strict";

function fetchBugs(callback) {
  setTimeout(() => callback(["UI glitch", "API timeout", "Login failure"]), 1000);
}

const shouldFail = Math.random() < 0.3;

function getBugs() {
  return new Promise((resolve, reject) => {
    fetchBugs(bugs => {
      if (shouldFail) {
        reject(new Error("API request failed"));
      } else {
        resolve(bugs);
      }
    });
  });
}

console.log("Fetching bugs...");

getBugs()
  .then(bugs => {
    const rows = bugs.map((bug, index) => ({ ID: index + 1, Bug: bug }));
    console.table(rows);
  })
  .catch(error => console.log(`Error: ${error.message}`));
