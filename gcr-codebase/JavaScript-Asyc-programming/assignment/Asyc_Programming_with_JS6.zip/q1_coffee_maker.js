"use strict";

const failureChance = 0.2;

function randomDelay() {
  return 1000 + Math.random() * 1000;
}

function step(message, failureMessage) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < failureChance) {
        reject(new Error(failureMessage));
      } else {
        console.log(message);
        resolve();
      }
    }, randomDelay());
  });
}

const boilWater = () => step("Step 1: Water boiled", "Kettle stopped working");
const brewCoffee = () => step("Step 2: Coffee brewed", "Coffee machine jammed");
const pourIntoCup = () => step("Step 3: Coffee poured into cup", "Cup broke");

console.log("Making coffee...");

boilWater()
  .then(brewCoffee)
  .then(pourIntoCup)
  .then(() => console.log("Coffee ready for the team!"))
  .catch(error => console.log(`Coffee process failed: ${error.message}`));
