"use strict";

console.log("Predicted order: Script start, Script end, Promise callback, Timeout callback");
console.log("--- Actual order ---");

console.log("Script start");

setTimeout(() => {
  console.log("Timeout callback");
  console.log("Prediction matched. Why: promise callbacks are microtasks, which run right after the current script, before the event loop picks the next macrotask such as a setTimeout callback (even with 0 ms delay).");
}, 0);

Promise.resolve().then(() => console.log("Promise callback"));

console.log("Script end");
