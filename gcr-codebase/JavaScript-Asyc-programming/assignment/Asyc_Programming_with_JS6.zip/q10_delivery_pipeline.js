"use strict";

const failureChance = 0.15;

function runStep(message, failureMessage) {
  return new Promise((resolve, reject) => {
    const delay = 1000 + Math.random() * 1000;
    setTimeout(() => {
      if (Math.random() < failureChance) {
        reject(new Error(failureMessage));
      } else {
        resolve(message);
      }
    }, delay);
  });
}

const takeOrder = () => runStep("Step 1: Order taken", "Order could not be taken");
const prepare = () => runStep("Step 2: Food prepared", "Kitchen could not prepare food");
const pack = () => runStep("Step 3: Package ready", "Packing failed");
const dispatch = () => runStep("Step 4: Out for delivery", "No rider available");
const deliver = () => runStep("Delivery completed!", "Delivery failed");

async function runPipeline() {
  console.log("Start Pipeline");
  try {
    console.log(await takeOrder());
    console.log(await prepare());
    console.log(await pack());
    console.log(await dispatch());
    console.log(await deliver());
  } catch (error) {
    console.log(`Error: ${error.message}`);
    console.log("Pipeline failed!");
  }
}

runPipeline();
console.log("(runPipeline paused at its first await; the main script has already finished)");
