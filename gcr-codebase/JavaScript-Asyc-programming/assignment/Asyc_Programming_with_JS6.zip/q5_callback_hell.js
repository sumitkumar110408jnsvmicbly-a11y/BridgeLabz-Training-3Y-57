"use strict";

function stageWithCallback(name, callback) {
  setTimeout(() => {
    console.log(`${name} done`);
    callback();
  }, 1000);
}

function stage(name) {
  return new Promise(resolve => {
    setTimeout(() => {
      console.log(`${name} done`);
      resolve();
    }, 1000);
  });
}

async function runWithAsyncAwait() {
  console.log("\n--- Async/await version ---");
  await stage("Design");
  await stage("Build");
  await stage("Test");
  await stage("Deploy");
  await stage("Celebrate");
  console.log("Why async/await is better: the steps read top to bottom like normal code, with no deep nesting and one place for error handling.");
}

console.log("--- Callback hell version ---");
stageWithCallback("Design", () => {
  stageWithCallback("Build", () => {
    stageWithCallback("Test", () => {
      stageWithCallback("Deploy", () => {
        stageWithCallback("Celebrate", () => {
          runWithAsyncAwait();
        });
      });
    });
  });
});
