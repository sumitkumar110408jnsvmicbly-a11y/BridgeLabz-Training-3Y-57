"use strict";

const MAX_ATTEMPTS = 3;

function submitOrder() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < 0.5) {
        resolve("Order submitted");
      } else {
        reject(new Error("Server error"));
      }
    }, 500);
  });
}

async function processOrder() {
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      await submitOrder();
      console.log(`Attempt ${attempt}: Success`);
      return "Order processed";
    } catch (error) {
      console.log(`Attempt ${attempt}: Failed`);
    }
  }
  throw new Error("Order could not be processed");
}

processOrder()
  .then(result => console.log(result))
  .catch(error => console.log(error.message));
