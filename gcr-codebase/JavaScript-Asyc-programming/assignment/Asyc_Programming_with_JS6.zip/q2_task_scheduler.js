"use strict";

console.log("Start");

setTimeout(() => {
  console.log("Macrotask: setTimeout callback");
  console.log("Why: after the current script, the event loop empties the microtask queue (promises) completely before taking the next macrotask (timers).");
}, 0);

Promise.resolve().then(() => console.log("Microtask: Promise.then callback"));

console.log("Synchronous log");

console.log("End");
