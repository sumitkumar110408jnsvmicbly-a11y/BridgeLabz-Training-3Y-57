"use strict";

const API_URL = "https://fakestoreapi.com/products";
const ERROR_MESSAGE = "Failed to load products. Please try again.";

function createProductCard(product) {
  const card = document.createElement("div");
  card.className = "card";

  const image = document.createElement("img");
  image.src = product.image;
  image.alt = product.title;

  const title = document.createElement("p");
  title.className = "title";
  title.textContent = product.title;

  const price = document.createElement("p");
  price.className = "price";
  price.textContent = `$${product.price}`;

  card.append(image, title, price);
  return card;
}

function renderProducts(products) {
  const container = document.getElementById("products");
  products.forEach(product => container.appendChild(createProductCard(product)));
}

async function loadProducts() {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const products = await response.json();

    products.forEach(product => {
      console.log(`Product: ${product.title}`);
      console.log(`Price: $${product.price}`);
      console.log(`Image: ${product.image}`);
      console.log("");
    });

    if (typeof document !== "undefined") {
      renderProducts(products);
    }
  } catch (error) {
    console.log(ERROR_MESSAGE);
    if (typeof document !== "undefined") {
      document.getElementById("message").textContent = ERROR_MESSAGE;
    }
  }
}

loadProducts();
