"use strict";

function Car(brand, model) {
  this.brand = brand;
  this.model = model;
}

Car.prototype.getDetails = function () {
  console.log(`Brand: ${this.brand}, Model: ${this.model}`);
};

const car1 = new Car("Toyota", "Fortuner");
const car2 = new Car("Honda", "City");

car1.getDetails();
car2.getDetails();

console.log("Shared method:", car1.getDetails === car2.getDetails);
console.log("Own property on car1:", car1.hasOwnProperty("getDetails"));
console.log("On prototype:", Car.prototype.hasOwnProperty("getDetails"));
