"use strict";

function makeMultiplier(multiplier) {
  return function (number) {
    return number * multiplier;
  };
}

const double = makeMultiplier(2);
const triple = makeMultiplier(3);

console.log(double(5));
console.log(triple(5));
console.log(triple(10));
console.log("Closure: the returned function remembers 'multiplier' from makeMultiplier even after makeMultiplier has finished running.");
