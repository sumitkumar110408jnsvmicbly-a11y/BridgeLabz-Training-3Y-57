"use strict";

Object.defineProperty(Array.prototype, "myMap", {
  value: function (callback, thisArg) {
    const result = [];
    for (let i = 0; i < this.length; i++) {
      if (i in this) {
        result[i] = callback.call(thisArg, this[i], i, this);
      }
    }
    return result;
  },
  writable: true,
  configurable: true,
  enumerable: false
});

console.log([1, 2, 3].myMap(num => num * 2));
console.log([1, 2, 3].map(num => num * 2));
console.log(["a", "b"].myMap((item, index) => `${index}:${item}`));
