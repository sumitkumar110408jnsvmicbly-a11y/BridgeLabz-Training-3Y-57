"use strict";

const userArrow = {
  name: "Sumit",
  showName: () => {
    console.log("Arrow function:", this.name);
  }
};

userArrow.showName();
console.log("Reason: an arrow function has no own 'this'; it uses the 'this' of the surrounding scope (not the object), which has no 'name'.");

const user = {
  name: "Sumit",
  showName: function () {
    console.log("Normal function:", this.name);
  }
};

user.showName();
