"use strict";

const user = { name: "John", email: "john@mail.com", age: 21 };

const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const ageInput = document.getElementById("age");
const output = document.getElementById("userOutput");
const statusBox = document.getElementById("status");

function showUser() {
  output.textContent = JSON.stringify(user, null, 2);
}

function updateUser() {
  user.name = nameInput.value;
  user.email = emailInput.value;
  user.age = Number(ageInput.value);
  showUser();
}

nameInput.value = user.name;
emailInput.value = user.email;
ageInput.value = user.age;
showUser();

[nameInput, emailInput, ageInput].forEach(input => input.addEventListener("input", updateUser));

document.getElementById("userForm").addEventListener("submit", event => {
  event.preventDefault();
  updateUser();
  statusBox.className = "result success";
  statusBox.textContent = "User object updated.";
  console.log(user);
});
