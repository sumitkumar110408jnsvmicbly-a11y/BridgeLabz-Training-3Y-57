"use strict";

class Book {
  constructor(title, author, isbn, isIssued = false) {
    this.title = title;
    this.author = author;
    this.isbn = isbn;
    this.isIssued = isIssued;
  }

  issueBook() {
    if (this.isIssued) {
      return `"${this.title}" is already issued.`;
    }
    this.isIssued = true;
    return `"${this.title}" has been issued.`;
  }

  returnBook() {
    if (!this.isIssued) {
      return `"${this.title}" was not issued.`;
    }
    this.isIssued = false;
    return `"${this.title}" has been returned.`;
  }
}

const books = [
  new Book("Clean Code", "Robert C. Martin", "9780132350884"),
  new Book("The Pragmatic Programmer", "Andrew Hunt", "9780135957059"),
  new Book("You Don't Know JS", "Kyle Simpson", "9781491904244", true),
  new Book("Eloquent JavaScript", "Marijn Haverbeke", "9781593279509")
];

function displayAvailableBooks() {
  console.log("Available books:");
  books
    .filter(book => !book.isIssued)
    .forEach(book => console.log(`${book.title} by ${book.author} (ISBN: ${book.isbn})`));
}

function issueBookByIsbn(isbn) {
  const book = books.find(item => item.isbn === isbn);
  if (!book) {
    console.log(`No book found with ISBN ${isbn}`);
    return;
  }
  console.log(book.issueBook());
}

const searchIsbn = process.argv[2] || "9780132350884";

displayAvailableBooks();
console.log(`\nSearching ISBN ${searchIsbn}...`);
issueBookByIsbn(searchIsbn);
console.log("");
displayAvailableBooks();
console.log("");
issueBookByIsbn("0000000000000");
console.log(books[0].returnBook());
