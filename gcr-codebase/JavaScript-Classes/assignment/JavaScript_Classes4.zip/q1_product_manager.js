"use strict";

class Product {
  constructor(id, name, price, category) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.category = category;
  }

  applyDiscount(percent) {
    this.price = this.price - (this.price * percent) / 100;
    return this.price;
  }

  getDetails() {
    return `#${this.id} | ${this.name} | Category: ${this.category} | Price: ₹${this.price.toFixed(2)}`;
  }
}

const products = [
  new Product(1, "Laptop", 55000, "Electronics"),
  new Product(2, "Headphones", 1800, "Electronics"),
  new Product(3, "Notebook", 120, "Stationery"),
  new Product(4, "Running Shoes", 3500, "Fashion"),
  new Product(5, "Pen Set", 450, "Stationery"),
  new Product(6, "Backpack", 1200, "Fashion")
];

console.log("All products:");
products.forEach(product => console.log(product.getDetails()));

console.log("\nProducts with price > 1000:");
products
  .filter(product => product.price > 1000)
  .forEach(product => console.log(product.getDetails()));

products[0].applyDiscount(10);
console.log("\nAfter 10% discount on Laptop:");
console.log(products[0].getDetails());
