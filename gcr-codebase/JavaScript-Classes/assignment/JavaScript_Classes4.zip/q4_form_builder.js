"use strict";

class FormBuilder {
  constructor(container, fields) {
    this.container = container;
    this.fields = fields;
    this.form = null;
  }

  render() {
    const fieldsHtml = this.fields
      .map((field, index) => {
        const id = `field_${index}`;
        const control =
          field.type === "textarea"
            ? `<textarea id="${id}" name="${id}" rows="3"></textarea>`
            : `<input type="${field.type}" id="${id}" name="${id}">`;
        return `<label for="${id}">${field.label}</label>${control}`;
      })
      .join("");

    this.container.innerHTML = `
      <form id="builtForm">
        ${fieldsHtml}
        <button type="submit">Submit</button>
      </form>
      <pre id="output"></pre>
    `;

    this.form = this.container.querySelector("#builtForm");
    this.form.addEventListener("submit", event => {
      event.preventDefault();
      const data = this.getFormData();
      this.container.querySelector("#output").textContent = JSON.stringify(data, null, 2);
      console.log(data);
    });
  }

  getFormData() {
    const data = {};
    this.fields.forEach((field, index) => {
      data[field.label] = this.form.elements[`field_${index}`].value;
    });
    return data;
  }
}

const fields = [
  { type: "text", label: "Username" },
  { type: "email", label: "Email" },
  { type: "password", label: "Password" },
  { type: "number", label: "Age" },
  { type: "textarea", label: "About You" }
];

const builder = new FormBuilder(document.getElementById("formContainer"), fields);
builder.render();
