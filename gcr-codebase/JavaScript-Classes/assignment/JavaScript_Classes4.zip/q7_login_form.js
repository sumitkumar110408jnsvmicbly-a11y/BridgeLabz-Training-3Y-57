"use strict";

const usernameRule = /^.{5,}$/;

const passwordRules = [
  { regex: /^.{8,}$/, message: "Password must be at least 8 characters long." },
  { regex: /\d/, message: "Password must include a number." },
  { regex: /[A-Z]/, message: "Password must include an uppercase letter." },
  { regex: /[a-z]/, message: "Password must include a lowercase letter." },
  { regex: /[^A-Za-z0-9]/, message: "Password must include a special character." }
];

const form = document.getElementById("loginForm");
const messageBox = document.getElementById("message");

form.addEventListener("submit", event => {
  event.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const errors = [];

  if (!usernameRule.test(username)) {
    errors.push("Username must be at least 5 characters long.");
  }

  passwordRules.forEach(rule => {
    if (!rule.regex.test(password)) {
      errors.push(rule.message);
    }
  });

  if (errors.length === 0) {
    messageBox.className = "success";
    messageBox.textContent = "Login successful!";
  } else {
    messageBox.className = "fail";
    messageBox.innerHTML = errors.map(error => `<div>${error}</div>`).join("");
  }
});
