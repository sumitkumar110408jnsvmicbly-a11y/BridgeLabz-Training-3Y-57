"use strict";

const rules = {
  name: {
    regex: /^[A-Za-z]+( [A-Za-z]+)*$/,
    message: "Name must contain only alphabets."
  },
  email: {
    regex: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
    message: "Enter a valid email address."
  },
  seats: {
    regex: /^([1-9]|10)$/,
    message: "Seats must be a number from 1 to 10."
  }
};

const form = document.getElementById("bookingForm");
const ticketBox = document.getElementById("ticket");

function validateField(fieldId) {
  const input = document.getElementById(fieldId);
  const error = document.getElementById(`${fieldId}Error`);
  const isValid = rules[fieldId].regex.test(input.value.trim());

  input.classList.toggle("valid", isValid);
  input.classList.toggle("invalid", !isValid);
  error.textContent = isValid ? "" : rules[fieldId].message;
  return isValid;
}

Object.keys(rules).forEach(fieldId => {
  document.getElementById(fieldId).addEventListener("input", () => validateField(fieldId));
});

form.addEventListener("submit", event => {
  event.preventDefault();
  const allValid = Object.keys(rules).map(validateField).every(Boolean);

  if (!allValid) {
    ticketBox.className = "result fail";
    ticketBox.textContent = "Please correct the highlighted fields.";
    return;
  }

  const booking = {
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    seats: Number(document.getElementById("seats").value)
  };

  ticketBox.className = "result success";
  ticketBox.innerHTML = `
    <h3>Ticket Confirmed</h3>
    <p>Name: ${booking.name}</p>
    <p>Email: ${booking.email}</p>
    <p>Seats: ${booking.seats}</p>
  `;
  console.log(booking);
});
