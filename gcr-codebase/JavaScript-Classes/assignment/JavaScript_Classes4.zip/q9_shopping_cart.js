"use strict";

class Cart {
  constructor() {
    this.items = [];
    this.discountPercent = 0;
  }

  addItem(name, price, quantity) {
    this.items.push({ name, price, quantity });
  }

  getTotal() {
    return this.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }

  applyCoupon(code) {
    const couponPattern = /^(SAVE|DISC)(\d{2})$/;
    const match = couponPattern.exec(code.trim().toUpperCase());

    if (!match) {
      this.discountPercent = 0;
      return false;
    }

    this.discountPercent = Number(match[2]);
    return true;
  }

  getFinalTotal() {
    const total = this.getTotal();
    return total - (total * this.discountPercent) / 100;
  }
}

const cart = new Cart();
cart.addItem("Keyboard", 1500, 1);
cart.addItem("Mouse", 600, 2);
cart.addItem("USB Cable", 150, 3);

console.log("Cart total:", cart.getTotal());

["SAVE20", "DISC10", "save15", "OFFER50", "SAVE5", "DISC100"].forEach(code => {
  const isValid = cart.applyCoupon(code);
  if (isValid) {
    console.log(`Coupon ${code}: valid, ${cart.discountPercent}% off -> Final total: ₹${cart.getFinalTotal().toFixed(2)}`);
  } else {
    console.log(`Coupon ${code}: invalid`);
  }
});
