"use strict";

class Employee {
  constructor(id, name, department, salary) {
    this.id = id;
    this.name = name;
    this.department = department;
    this.salary = salary;
  }

  getAnnualSalary() {
    return this.salary * 12;
  }

  applyBonus(percent) {
    this.salary += (this.salary * percent) / 100;
    return this.salary;
  }
}

const employees = [
  new Employee(101, "Amit", "HR", 35000),
  new Employee(102, "Sara", "Finance", 48000),
  new Employee(103, "Kiran", "Tech", 72000),
  new Employee(104, "Neha", "Support", 30000),
  new Employee(105, "Ravi", "Tech", 65000)
];

console.log("Annual salary of each employee:");
employees.forEach(employee => {
  console.log(`${employee.name} (${employee.department}): ₹${employee.getAnnualSalary()}`);
});

const totalPayout = employees.reduce((sum, employee) => sum + employee.getAnnualSalary(), 0);
console.log(`\nTotal annual payout: ₹${totalPayout}`);

employees[0].applyBonus(10);
console.log(`\nAfter 10% bonus, ${employees[0].name}'s annual salary: ₹${employees[0].getAnnualSalary()}`);
console.log(`New total annual payout: ₹${employees.reduce((sum, employee) => sum + employee.getAnnualSalary(), 0)}`);
