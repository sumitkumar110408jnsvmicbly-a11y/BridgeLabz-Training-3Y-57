"use strict";

const rules = {
  name: {
    regex: /^[A-Za-z]+( [A-Za-z]+)*$/,
    message: "Name must contain only alphabets."
  },
  email: {
    regex: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
    message: "Enter a valid email (example@domain.com)."
  },
  phone: {
    regex: /^\d{10}$/,
    message: "Phone must be exactly 10 digits."
  },
  password: {
    regex: /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/,
    message: "Password needs 1 uppercase letter, 1 number and 1 special character."
  }
};

const form = document.getElementById("studentForm");
const messageBox = document.getElementById("message");

function validateField(fieldId) {
  const input = document.getElementById(fieldId);
  const error = document.getElementById(`${fieldId}Error`);
  const value = fieldId === "password" ? input.value : input.value.trim();
  const isValid = rules[fieldId].regex.test(value);

  input.classList.toggle("valid", isValid);
  input.classList.toggle("invalid", !isValid);
  error.textContent = isValid ? "" : rules[fieldId].message;
  return isValid;
}

Object.keys(rules).forEach(fieldId => {
  document.getElementById(fieldId).addEventListener("input", () => validateField(fieldId));
});

form.addEventListener("submit", event => {
  event.preventDefault();
  const results = Object.keys(rules).map(validateField);
  const allValid = results.every(Boolean);

  messageBox.className = allValid ? "success" : "fail";
  messageBox.textContent = allValid
    ? "Registration successful!"
    : "Please fix the errors above.";
});
